import react from 'react';

export default class ImageDisplay extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return(
      <div className="images">
        <GetImageForm />
      </div>
    )
  }
}
